package com.pack.service;

import java.util.List;

import com.pack.model.Customer;

import jdk.internal.org.objectweb.asm.tree.TryCatchBlockNode;

public interface CustomerService {

	public int insertCustomer(Customer c);
	public List<Customer> fetchCustomers();
}
