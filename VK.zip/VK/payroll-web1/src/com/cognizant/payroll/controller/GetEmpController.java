package com.cognizant.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.payroll.dao.EmployeeDao;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Employee;

/**
 * Servlet implementation class GetEmpController
 */
public class GetEmpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetEmpController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

				String empid=				request.getParameter("empid");
				int empId=Integer.parseInt(empid);
				System.out.println(empid);
				// based in id get address,dept,desig,skillet
		// select * from emp where id=empid
				//add to jsp
		
		  EmployeeDao employeeDao=new EmployeeDao();
		  try {
		Employee employee = employeeDao.getEmployeeDetailsById(empId);
		request.setAttribute("employee", employee);
		RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/update.jsp");
		dispatcher.forward(request, response);
	
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		
				
			//	RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/update.jsp");
			//	dispatcher.forward(request, response);
				
		
		
		
		
		
		
	}

}
