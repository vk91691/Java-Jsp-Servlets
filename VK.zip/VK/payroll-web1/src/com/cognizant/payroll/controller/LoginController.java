package com.cognizant.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.payroll.dao.EmployeeDao;
import com.cognizant.payroll.dao.LoginDao;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Employee;
import com.cognizant.payroll.model.LoginDetails;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub

		System.out.println("inint()");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {

		System.out.println("Destry()");
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		ServletConfig config = this.getServletConfig();

		System.out.println("post service");
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		if (request.getParameter("submit").equals("Login")) {

			String username = request.getParameter("username");
			String password = request.getParameter("password");

			LoginDetails loginDetails = new LoginDetails(username, password);
			LoginDao loginDao = new LoginDao();
			try {
				String name = loginDao.doLogin(loginDetails);

				if (name.equals("")) {
					// out.write("<b style='color:red'> Username password is wrong</b>");
					request.setAttribute("error", "Username password is wrong");
					RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/login.jsp");
					dispatcher.forward(request, response);

				} else {

					HttpSession httpSession = request.getSession();
					httpSession.setAttribute("user", loginDetails);

					EmployeeDao employeeDao = new EmployeeDao();
					List<Employee> list = employeeDao.getEmployeeDetails();
					request.setAttribute("emplist", list);

					System.out.println(httpSession);
					RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/home.jsp");
					dispatcher.forward(request, response);
					// out.write("User is valid diaply home page");

				}
			} catch (PayrollException e) {
				// TODO Auto-generated catch block
				// out.write("<b style='color:red'>"+e.getMessage()+"</b>");
				request.setAttribute("error", e.getMessage());
				RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/login.jsp");
				dispatcher.forward(request, response);
				e.printStackTrace();
			}

		}

	}

}
