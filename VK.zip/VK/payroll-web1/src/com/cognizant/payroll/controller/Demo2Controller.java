package com.cognizant.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Demo2Controller
 */
public class Demo2Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Demo2Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out=	response.getWriter();	
		response.setContentType("text/html");
			ServletConfig config=	this.getServletConfig();
			ServletContext application=this.getServletContext();
			String location=application.getInitParameter("reportlocation");
			out.print("the data from apliication object from xml file as "+location+"<br>");
			
		 String fileinfo=   config.getInitParameter("fileinfo");
			
		 String driver=   config.getInitParameter("dbdriver");
		 String user=   config.getInitParameter("dbuser");
		 String pass=   config.getInitParameter("dbpwd");
		 String url=   config.getInitParameter("dburl");

		 out.print("Accessing the DemoController Cofig object<br>");
					out.print(driver+"<br>");
			out.print(user+"<br>");
			out.print(pass+"<br>");
			out.print(url+"<br>");
			out.print(fileinfo+" is generated in the location by using abocve db information");
			
			/*All param once*/
			
			Enumeration<String> allParam=config.getInitParameterNames();
			while (allParam.hasMoreElements()) {
				String string = (String) allParam.nextElement();
				System.out.println(string);
				
				System.out.println(config.getInitParameter(string));
				
			}	
			
			
	}

}
