package com.cognizant.payroll.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.payroll.dao.AddressDao;
import com.cognizant.payroll.dao.EmployeeDao;
import com.cognizant.payroll.dao.EmployeeSaveAllDao;
import com.cognizant.payroll.dao.SkillSetDao;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Address;
import com.cognizant.payroll.model.Department;
import com.cognizant.payroll.model.Designation;
import com.cognizant.payroll.model.Employee;
import com.cognizant.payroll.model.EmployeeSkillSet;
import com.cognizant.payroll.model.Skill;
import com.cognizant.payroll.util.Connectionutil;

/**
 * Servlet implementation class RegisterController
 */
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		// employeeName, dob, mobile, salary, email, gender, street, city,
		// state, country, pin, designationId, skillId, submit

		if (request.getParameter("submit").equals("Register")) {

			String employeeName = request.getParameter("employeeName");
			String dob = request.getParameter("dob");
			LocalDate date = LocalDate.parse(dob);

			String mobile = request.getParameter("mobile");
			long cell = Long.parseLong(mobile);

			String salary = request.getParameter("salary");
			double sal = Double.parseDouble(salary);

			String email = request.getParameter("email");

			String gender = request.getParameter("gender");
			char gen = gender.charAt(0);

			String street = request.getParameter("street");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String country = request.getParameter("country");

			String pin = request.getParameter("pin");
			Integer pn = Integer.parseInt(pin);

			String designationId = request.getParameter("designationId");
			Integer desigId = Integer.parseInt(designationId);

			String departmentId = request.getParameter("departmentId");
			Integer deptId = Integer.parseInt(departmentId);

			String arr[] = request.getParameterValues("skillId");
			
			EmployeeSaveAllDao dao=new EmployeeSaveAllDao();
			
			Address address=new Address(0, street, city, state, pn, country);
			
			Department department=new Department();
			department.setDepartmentId(deptId);
			
			Designation designation=new Designation();
			designation.setDesignationId(desigId);
			
			
		  Employee employee=new Employee(0, employeeName, date, cell, sal, email, gen,
				  department, address, designation);
			
			try {
				dao.saveAllEmpDetails(employee, arr);
				
				
			} catch (PayrollException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
			
		/*Map<String, String[]> map = request.getParameterMap();
		System.out.println(map);

		Set<String> keys = map.keySet();
		System.out.println(keys);
		for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			System.out.print(key + "= ");

			String[] arr = map.get(key);

			for (String string : arr) {
				System.out.print(string);
			}

			System.out.println();
*/
		}

	}
}


