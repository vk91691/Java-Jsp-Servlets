package com.cognizant.payroll.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.payroll.dao.EmployeeSaveAllDao;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Address;
import com.cognizant.payroll.model.Department;
import com.cognizant.payroll.model.Designation;
import com.cognizant.payroll.model.Employee;

/**
 * Servlet implementation class UpdateController
 */
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		if (request.getParameter("submit").equals("update")) {
            
			String employeeIdd = request.getParameter("employeeId");	
			int  employeeId = Integer.parseInt(employeeIdd);	
			
			String addressIdd=request.getParameter("addressId");
			int addressId=Integer.parseInt(addressIdd);
			
			String employeeName = request.getParameter("employeeName");
			String dob = request.getParameter("dob");
			LocalDate date = LocalDate.parse(dob);

			String mobile = request.getParameter("mobile");
			long cell = Long.parseLong(mobile);

			String salary = request.getParameter("salary");
			double sal = Double.parseDouble(salary);

			String email = request.getParameter("email");

			String gender = request.getParameter("gender");
			char gen = gender.charAt(0);

			String street = request.getParameter("street");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String country = request.getParameter("country");

			String pin = request.getParameter("pin");
			Integer pn = Integer.parseInt(pin);

			String designationId = request.getParameter("designationId");
			Integer desigId = Integer.parseInt(designationId);

			String departmentId = request.getParameter("departmentId");
			Integer deptId = Integer.parseInt(departmentId);

			String arr[] = request.getParameterValues("skillId");
			
			EmployeeSaveAllDao dao=new EmployeeSaveAllDao();
			
			Address address=new Address(0, street, city, state, pn, country);
			address.setAddressId(addressId);
			Department department=new Department();
			department.setDepartmentId(deptId);
			
			Designation designation=new Designation();
			designation.setDesignationId(desigId);
			
			
		    Employee employee=new Employee(0, employeeName, date, cell, sal, email, gen,department, address, designation);
			employee.setEmployeeId(employeeId);
			try {
			int flag=dao.updateAllEmpDetails(employee, arr);
		//	System.out.println(flag);
			if(flag==1)
			{
				request.setAttribute("message", "successfully updated");
				RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/success.jsp");
				dispatcher.forward(request, response);
			}
			else
			{
				request.setAttribute("message", "Not successfully updated");
				RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/error.jsp");
				dispatcher.forward(request, response);
				
			}
				
				
			} catch (PayrollException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
	}

}
