package com.cognizant.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.payroll.exception.IPayrollMessages;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.LoginDetails;
import com.cognizant.payroll.util.Connectionutil;

public class LoginDao {
	public String doLogin(LoginDetails loginDetails) throws PayrollException {
		String user = "";
		Connection connObj = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connObj = Connectionutil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else
				System.out.println("Got Connected");

			preparedStatement = connObj
					.prepareStatement("Select username,password from login where username=? and password=?");
			preparedStatement.setString(1, loginDetails.getUsername());
			preparedStatement.setString(2, loginDetails.getPassword());
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				String uname = resultSet.getString("username");
				String pword = resultSet.getString("password");
				// System.out.println("Welcome-->"+uname);
				user = uname;
			} else
				return user;
			if (resultSet != null)
				resultSet.close();
			if (preparedStatement != null)
				preparedStatement.close();
			if (connObj != null)
				connObj.close();
		} catch (ClassNotFoundException classNotFoundException) {
			// classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.DRIVER_MISSING_ERROR);
		} catch (SQLException sqlException) {
			// classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
		}
		return user;
	}
}
