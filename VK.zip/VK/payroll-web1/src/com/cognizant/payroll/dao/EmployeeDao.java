package com.cognizant.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.payroll.exception.IPayrollMessages;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Address;
import com.cognizant.payroll.model.Department;
import com.cognizant.payroll.model.Designation;
import com.cognizant.payroll.model.Employee;
import com.cognizant.payroll.model.EmployeeSkillSet;
import com.cognizant.payroll.model.LoginDetails;
import com.cognizant.payroll.util.Connectionutil;

public class EmployeeDao {

	public EmployeeDao() {
		// TODO Auto-generated constructor stub
	}
	
	static private EmployeeDao employeeDao=null;
	public static EmployeeDao getEmployeeDao() {
		if(employeeDao==null)
		{
			employeeDao =new EmployeeDao();
		}
		return employeeDao;
	}
	

	public int saveEmployee(Employee employee, Connection connObj) throws PayrollException {

		// Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int empId = 0;
		String query = "insert into employee(EM_NAME,EM_DOB,EM_MOBILE,EM_SALARY,EM_EMAIL,EM_DP_FK,EM_AD_FK,EM_DE_FK,gender) "
				+ "values (?,?,?,?,?,?,?,?,?)";
		try {
			// connObj=ConnectionUtil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else {
				System.out.println("Got Connected");
			}
			preparedStatement = connObj.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

			preparedStatement.setString(1, employee.getEmployeeName());
			preparedStatement.setString(2, employee.getDob().toString());
			preparedStatement.setLong(3, employee.getMobile());
			preparedStatement.setDouble(4, employee.getSalary());
			preparedStatement.setString(5, employee.getEmail());
			preparedStatement.setInt(6, employee.getDepartment().getDepartmentId());
			preparedStatement.setInt(7, employee.getAddress().getAddressId());
			preparedStatement.setInt(8, employee.getDesignation().getDesignationId());
			preparedStatement.setString(9, employee.getGender() + "");

			int count = preparedStatement.executeUpdate();

			resultSet = preparedStatement.getGeneratedKeys();
			if (resultSet.next()) {
				empId = resultSet.getInt(1);
			}

			if (count >= 1) {
				System.out.println("Employee is save");
			} else {

				throw new PayrollException("Employee is not saved some internal error");
			}

			/*
			 * if(resultSet!=null) resultSet.close();
			 */

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			// classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new PayrollException(e.getMessage());
				}

			}
			/*
			 * if(connObj!=null) { connObj.close(); }
			 */

		}

		return empId;
	}
	public int updateEmployee(Employee employee, Connection connObj) throws PayrollException {

		// Connection connObj=null;
		int count=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int empId = 0;
		String query = "update employee set EM_NAME=?,EM_DOB=?,EM_MOBILE=?,EM_SALARY=?,EM_EMAIL=?,EM_DP_FK=?,EM_AD_FK=?,EM_DE_FK=?,gender=? where EM_ID=? ";		try {
			// connObj=ConnectionUtil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else {
				System.out.println("Got Connected");
			}
			preparedStatement = connObj.prepareStatement(query);

			preparedStatement.setString(1, employee.getEmployeeName());
			preparedStatement.setString(2, employee.getDob().toString());
			preparedStatement.setLong(3, employee.getMobile());
			preparedStatement.setDouble(4, employee.getSalary());
			preparedStatement.setString(5, employee.getEmail());
			preparedStatement.setInt(6, employee.getDepartment().getDepartmentId());
			preparedStatement.setInt(7, employee.getAddress().getAddressId());
			preparedStatement.setInt(8, employee.getDesignation().getDesignationId());
			preparedStatement.setString(9, employee.getGender() + "");

			preparedStatement.setInt(10, employee.getEmployeeId());
		 count = preparedStatement.executeUpdate();


			if (count >= 1) {
				System.out.println("Employee is save");
			} else {

				throw new PayrollException("Employee is not saved some internal error");
			}

			/*
			 * if(resultSet!=null) resultSet.close();
			 */

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			// classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new PayrollException(e.getMessage());
				}

			}
			/*
			 * if(connObj!=null) { connObj.close(); }
			 */

		}

		return count;
	}
	
	
	public List<Employee> getEmployeeDetails() throws PayrollException
	{
		List<Employee> list=new ArrayList<>();
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query="select e.*,a.*,de.*,d.*,group_concat(s.sk_name) as text\r\n" + 
				"from employee e join department d join address a join designation de join skill s join employee_skillset esk\r\n" + 
				"on e.em_dp_fk=d.em_dp_id and e.em_ad_fk=a.em_ad_id and e.em_de_fk=de.em_de_id and s.em_sk_id=esk.EM_SK_ID_FK and esk.EM_ID_FK =e.em_id\r\n" + 
				"group by e.em_id order by e.em_name desc, a.ad_street ";
		try
		{   
			connObj=Connectionutil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else {
			System.out.println("Got Connected");
		}
			
	 preparedStatement = connObj.prepareStatement(query);
	 
	 
		
		resultSet = preparedStatement.executeQuery();
		while(resultSet.next())
		{	
			int employeeId=resultSet.getInt("EM_ID");
			String employeeName =resultSet.getString("EM_NAME");
		    String dob =resultSet.getString("EM_DOB");
		    int mobile=resultSet.getInt("EM_MOBILE");
		    double salary=resultSet.getDouble("EM_SALARY");
		    String email=resultSet.getString("EM_EMAIL");
		    String gender=resultSet.getString("gender");
		    
		    //address data
			int addressId=resultSet.getInt("EM_AD_ID");
			String street =resultSet.getString("AD_STREET");
			String city =resultSet.getString("AD_CITY");
			String state =resultSet.getString("AD_STATE");
			String country =resultSet.getString("AD_COUNTRY");
			   int pin=resultSet.getInt("AD_PIN");
			   
			   Address address=new Address(addressId, street, city, state, pin, country);
			   
			   //designation data
			   int designationId=resultSet.getInt("EM_DE_ID");
			   String designationName =resultSet.getString("DE_NAME");
			 
			    Designation designation=new Designation();
			   designation.setDesignationId(designationId);
			   designation.setDesignationName(designationName);
			   
				  //department data
			   int departmentId=resultSet.getInt("EM_DP_ID");
			   String departmentName =resultSet.getString("DP_NAME");
			   String departmentLocation=resultSet.getString("DP_LOCATION");
			   Department department=new Department(departmentId, departmentName, departmentLocation);
			   
			   //set all to employee
			   Employee employee=new Employee(employeeId, employeeName, LocalDate.parse(dob),
					   mobile, salary, email, gender.charAt(0), department, address, designation);
			   
			   String text=resultSet.getString("text");
			   employee.setSkillText(text);
				
			   // add employee to list
			list.add(employee);
			//System.out.println("Welcome-->"+uname);
		//http://10.223.70.118/courses/web/index.html	
		}
		
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			classNotFoundException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
			}
		     finally {
				try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}catch(SQLException exception) {
				exception.printStackTrace();
				throw new PayrollException(IPayrollMessages.CLOSING_RESOURCE_ERROR);
				
			}
	}
		return list;
}


	public Employee getEmployeeDetailsById(int empId) throws PayrollException
	{
		List<Employee> list=new ArrayList<>();
		 Employee employee=null;
			
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String query="select e.*,a.*,de.*,d.*,group_concat(s.sk_name) as text\r\n" + 
				"from employee e join department d join address a join designation de join skill s join employee_skillset esk\r\n" + 
				"on e.em_dp_fk=d.em_dp_id and e.em_ad_fk=a.em_ad_id and e.em_de_fk=de.em_de_id and s.em_sk_id=esk.EM_SK_ID_FK and esk.EM_ID_FK =e.em_id\r\n" + 
				"where EM_ID=?  group by e.em_id order by e.em_name desc, a.ad_street ";
		try
		{   
			connObj=Connectionutil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else {
			System.out.println("Got Connected");
		}
			
	 preparedStatement = connObj.prepareStatement(query);
	 preparedStatement.setInt(1, empId);
	 
	 
		
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{	
			int employeeId=resultSet.getInt("EM_ID");
			String employeeName =resultSet.getString("EM_NAME");
		    String dob =resultSet.getString("EM_DOB");
		    int mobile=resultSet.getInt("EM_MOBILE");
		    double salary=resultSet.getDouble("EM_SALARY");
		    String email=resultSet.getString("EM_EMAIL");
		    String gender=resultSet.getString("gender");
		    
		    //address data
			int addressId=resultSet.getInt("EM_AD_ID");
			String street =resultSet.getString("AD_STREET");
			String city =resultSet.getString("AD_CITY");
			String state =resultSet.getString("AD_STATE");
			String country =resultSet.getString("AD_COUNTRY");
			   int pin=resultSet.getInt("AD_PIN");
			   
			   Address address=new Address(addressId, street, city, state, pin, country);
			   
			   //designation data
			   int designationId=resultSet.getInt("EM_DE_ID");
			   String designationName =resultSet.getString("DE_NAME");
			 
			    Designation designation=new Designation();
			   designation.setDesignationId(designationId);
			   designation.setDesignationName(designationName);
			   
				  //department data
			   int departmentId=resultSet.getInt("EM_DP_ID");
			   String departmentName =resultSet.getString("DP_NAME");
			   String departmentLocation=resultSet.getString("DP_LOCATION");
			   Department department=new Department(departmentId, departmentName, departmentLocation);
			   
			   //set all to employee
			    employee=new Employee(employeeId, employeeName, LocalDate.parse(dob),
					   mobile, salary, email, gender.charAt(0), department, address, designation);
			   
			   String text=resultSet.getString("text");
			   employee.setSkillText(text);
				
			   // add employee to list
		//	list.add(employee);
			//System.out.println("Welcome-->"+uname);
		//http://10.223.70.118/courses/web/index.html	
		}
		
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			classNotFoundException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
			}
		     finally {
				try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}catch(SQLException exception) {
				exception.printStackTrace();
				throw new PayrollException(IPayrollMessages.CLOSING_RESOURCE_ERROR);
				
			}
	}
		return employee;
}


}

