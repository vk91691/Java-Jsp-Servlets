package com.cognizant.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cognizant.payroll.exception.IPayrollMessages;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Address;
import com.cognizant.payroll.model.LoginDetails;
import com.cognizant.payroll.util.Connectionutil;

public class AddressDao {

	public AddressDao() {
		// TODO Auto-generated constructor stub
	}

	public int saveAddress(Address address, Connection connObj) throws PayrollException {

		// Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int addressId = 0;
		String query = "insert into address (AD_STREET,AD_CITY,AD_STATE,AD_PIN,AD_COUNTRY) values (?,?,?,?,?)";
		try {
			// connObj=ConnectionUtil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else {
				System.out.println("Got Connected");
			}
			preparedStatement = connObj.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, address.getStreet());

			preparedStatement.setString(2, address.getCity());
			preparedStatement.setString(3, address.getState());
			preparedStatement.setInt(4, address.getPin());
			preparedStatement.setString(5, address.getCountry());

			int count = preparedStatement.executeUpdate();

			resultSet = preparedStatement.getGeneratedKeys();
			if (resultSet.next()) {
				addressId = resultSet.getInt(1);
			}

			if (count >= 1) {
				System.out.println("Address is save");
			} else {

				throw new PayrollException("Address is not saved some internal error");
			}
		}

		catch (SQLException sqlException) {
			// classNotFoundException.printStackTrace();
			sqlException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
					// TODO Auto-generated catch block
					throw new PayrollException(e.getMessage());
				}

			}
			/*
			 * if(connObj!=null) { connObj.close(); }
			 */

		}

		return addressId;
	}
	
	public int updateAddress(Address address, Connection connObj) throws PayrollException {

		// Connection connObj=null;
		int count =0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int addressId = 0;
		String query = "update address set AD_STREET=?,AD_CITY=?,AD_STATE=?,AD_PIN=?,AD_COUNTRY=? where EM_AD_ID=?";
		try {
			// connObj=ConnectionUtil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else {
				System.out.println("Got Connected");
			}
			preparedStatement = connObj.prepareStatement(query);
			preparedStatement.setString(1, address.getStreet());

			preparedStatement.setString(2, address.getCity());
			preparedStatement.setString(3, address.getState());
			preparedStatement.setInt(4, address.getPin());
			preparedStatement.setString(5, address.getCountry());
			
			preparedStatement.setInt(6, address.getAddressId());
		
			 count = preparedStatement.executeUpdate();
			if (count >= 1) {
				System.out.println("Address is updated");
			} else {
               
				throw new PayrollException("Address is not updated some internal error");
			}
		}

		catch (SQLException sqlException) {
			// classNotFoundException.printStackTrace();
			sqlException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
					// TODO Auto-generated catch block
					throw new PayrollException(e.getMessage());
				}

			}
			/*
			 * if(connObj!=null) { connObj.close(); }
			 */

		}

		return count;
	}


}
