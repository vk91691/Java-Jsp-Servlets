package com.cognizant.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cognizant.payroll.exception.IPayrollMessages;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Address;
import com.cognizant.payroll.model.EmployeeSkillSet;
import com.cognizant.payroll.util.Connectionutil;

public class SkillSetDao {

	public SkillSetDao() {
		// TODO Auto-generated constructor stub
	}

	
	public int saveSkillSet(EmployeeSkillSet employeeSkillSet,Connection connObj) throws PayrollException
	{
		
		
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int empSkillSetId=0;
		String query="insert into employee_skillset (EM_ID_FK,EM_SK_ID_FK) values (?,?)";
		try
		{   
			//connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else {
			System.out.println("Got Connected");
		}
	 preparedStatement = connObj.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
		
	 preparedStatement.setInt(1, employeeSkillSet.getEmployee().getEmployeeId());
	 
	 preparedStatement.setInt(2, employeeSkillSet.getSkill().getSkillId());
	 
		
	int count=	preparedStatement.executeUpdate();
	
	 resultSet= preparedStatement.getGeneratedKeys();
	 if(resultSet.next()) {
		 empSkillSetId=	 resultSet.getInt(1);
	 }
	
	if(count>=1) {
	System.out.println("SkillSet is save");	
	}else {
		
		throw new PayrollException("SkillSet is not saved some internal error");
	}
		}
		
		
		
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
			}finally {
				if(preparedStatement!=null)
				{	try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
					// TODO Auto-generated catch block
					throw new PayrollException(e.getMessage());
				}
				
				}
				/*
				if(connObj!=null) {
					connObj.close();
				}*/
				
			}
		
		return  empSkillSetId;
	}
	public int removeSkillSet(EmployeeSkillSet employeeSkillSet,Connection connObj) throws PayrollException
	{
		int count=0;
		
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int empSkillSetId=0;
		String query="delete from employee_skillset where EM_ID_FK=?";
		try
		{   
			//connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else {
			System.out.println("Got Connected");
		}
	 preparedStatement = connObj.prepareStatement(query);
		
	 preparedStatement.setInt(1, employeeSkillSet.getEmployee().getEmployeeId());
	 
	  count= preparedStatement.executeUpdate();
	
	if(count>=1) {
	System.out.println("SkillSet is save");	
	}else {
		
		throw new PayrollException("SkillSet is not saved some internal error");
	}
		}
		
		
		
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new PayrollException(IPayrollMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PayrollException(IPayrollMessages.CONTACT_TO_ADMIN_ERROR);
			}finally {
				if(preparedStatement!=null)
				{	try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
					// TODO Auto-generated catch block
					throw new PayrollException(e.getMessage());
				}
				
				}
				/*
				if(connObj!=null) {
					connObj.close();
				}*/
				
			}
		
		return  count;
	}
	
}
