package com.cognizant.payroll.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.cognizant.payroll.exception.IPayrollMessages;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.Address;
import com.cognizant.payroll.model.Department;
import com.cognizant.payroll.model.Designation;
import com.cognizant.payroll.model.Employee;
import com.cognizant.payroll.model.EmployeeSkillSet;
import com.cognizant.payroll.model.Skill;
import com.cognizant.payroll.util.Connectionutil;

public class EmployeeSaveAllDao {

	public EmployeeSaveAllDao() {
		// TODO Auto-generated constructor stub
	}
	
	
	public String saveAllEmpDetails(Employee employee,String arr[])throws PayrollException {
		
		//Address address = new Address(0, street, city, state, pn, country);

		AddressDao addressDao = new AddressDao();
		int generateId;
		Connection connObj = null;
		try {
			connObj = Connectionutil.getConnection();
			connObj.setAutoCommit(false);

			generateId = addressDao.saveAddress(employee.getAddress(), connObj);
			employee.getAddress().setAddressId(generateId);
			
			Department department = new Department();
			department.setDepartmentId(employee.getDepartment().getDepartmentId());

			Designation designation = new Designation();
			designation.setDesignationId(employee.getDesignation().getDesignationId());
			
			
			EmployeeDao employeeDao = new EmployeeDao();
			int genEmpId = employeeDao.saveEmployee(employee, connObj);
			employee.setEmployeeId(genEmpId);

			SkillSetDao skillSetDao = new SkillSetDao();
			for (int i = 0; i < arr.length; i++) {

				String skillIdd = arr[i];
				int skillId = Integer.parseInt(skillIdd);
				EmployeeSkillSet employeeSkillSet = new EmployeeSkillSet();

				Skill skill = new Skill();
				skill.setSkillId(skillId);

				employeeSkillSet.setEmployee(employee);
				employeeSkillSet.setSkill(skill);
				skillSetDao.saveSkillSet(employeeSkillSet, connObj);

			}
			connObj.commit();

		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				throw new PayrollException(IPayrollMessages.REGISTER_ADMIN_ERROR);
			}

			System.out.print("data not save");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw new PayrollException(IPayrollMessages.DRIVER_MISSING_ERROR);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				throw new PayrollException(IPayrollMessages.REGISTER_ADMIN_ERROR);
				
			}
			
			e.printStackTrace();
		} finally {
			if (connObj != null) {
				try {
					connObj.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new PayrollException(IPayrollMessages.CLOSING_RESOURCE_ERROR);
					
				
				}

			}
		}

	

		return "";
	}
	public int updateAllEmpDetails(Employee employee,String arr[])throws PayrollException {
		
		//Address address = new Address(0, street, city, state, pn, country);

		AddressDao addressDao = new AddressDao();
		int count1=0;
		int count2=0;
		int count3=0;
		int flag=0;
		Connection connObj = null;
		try {
			connObj = Connectionutil.getConnection();
			connObj.setAutoCommit(false);
			SkillSetDao skillSetDao = new SkillSetDao();
			
			EmployeeSkillSet employeeskillset=new EmployeeSkillSet();
			count1 = addressDao.updateAddress(employee.getAddress(), connObj);
		
			Department department = new Department();
			department.setDepartmentId(employee.getDepartment().getDepartmentId());

			Designation designation = new Designation();
			designation.setDesignationId(employee.getDesignation().getDesignationId());
			
			
			EmployeeDao employeeDao = new EmployeeDao();
			count2 = employeeDao.updateEmployee(employee, connObj);
            //remove existing skills
			
			EmployeeSkillSet employeeSkillSet1=new EmployeeSkillSet();
			employeeSkillSet1.setEmployee(employee);
			count3=skillSetDao.removeSkillSet(employeeSkillSet1, connObj);
			
				for (int i = 0; i < arr.length; i++) {

				String skillIdd = arr[i];
				int skillId = Integer.parseInt(skillIdd);
				//EmployeeSkillSet employeeSkillSet = new EmployeeSkillSet();

				Skill skill = new Skill();
				skill.setSkillId(skillId);
				EmployeeSkillSet employeeSkillSet=new EmployeeSkillSet();
				
				employeeSkillSet.setEmployee(employee);
				employeeSkillSet.setSkill(skill);
				skillSetDao.saveSkillSet(employeeSkillSet, connObj);

			}
			connObj.commit();
			if(count1>=1 && count2>=1 && count3>=1)
			{
				flag=1;
			}

		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				throw new PayrollException(IPayrollMessages.REGISTER_ADMIN_ERROR);
			}

			System.out.print("data not save");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw new PayrollException(IPayrollMessages.DRIVER_MISSING_ERROR);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				throw new PayrollException(IPayrollMessages.REGISTER_ADMIN_ERROR);
				
			}
			System.out.println("data is not save");
			
			e.printStackTrace();
		} finally {
			if (connObj != null) {
				try {
					connObj.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new PayrollException(IPayrollMessages.CLOSING_RESOURCE_ERROR);
					
				
				}

			}
		}

		return flag;
	}

}
