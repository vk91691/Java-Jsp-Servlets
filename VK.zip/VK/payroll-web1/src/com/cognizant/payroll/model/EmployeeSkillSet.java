package com.cognizant.payroll.model;

public class EmployeeSkillSet {

	public EmployeeSkillSet() {
		// TODO Auto-generated constructor stub
	}
	
	private int skillSetId;
	// having FKs
	private Skill skill;
	private Employee employee;
	
	
	public int getSkillSetId() {
		return skillSetId;
	}
	public void setSkillSetId(int skillSetId) {
		this.skillSetId = skillSetId;
	}
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((employee == null) ? 0 : employee.hashCode());
		result = prime * result + ((skill == null) ? 0 : skill.hashCode());
		result = prime * result + skillSetId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeSkillSet other = (EmployeeSkillSet) obj;
		if (employee == null) {
			if (other.employee != null)
				return false;
		} else if (!employee.equals(other.employee))
			return false;
		if (skill == null) {
			if (other.skill != null)
				return false;
		} else if (!skill.equals(other.skill))
			return false;
		if (skillSetId != other.skillSetId)
			return false;
		return true;
	}
	public EmployeeSkillSet(int skillSetId, Skill skill, Employee employee) {
		super();
		this.skillSetId = skillSetId;
		this.skill = skill;
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "EmployeeSkillSet [skillSetId=" + skillSetId + ", skill=" + skill + ", employee=" + employee + "]";
	}
	
	
	

}
