package com.cognizant.payroll.util;

import java.sql.*;


public class Connectionutil {
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Connection con=null;
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/payroll","root","root");
		return con;
	}

}
