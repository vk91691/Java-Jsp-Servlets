package com.cognizant.payroll.exception;

public interface IPayrollMessages {
	public String DRIVER_MISSING_ERROR="Driver is missing.";
	public String SOME_SQL_ERROR="Some sql Errors contact to admin.";
	public String CONTACT_TO_ADMIN_ERROR="Please contact to admin";
	public String REGISTER_ADMIN_ERROR="Error while registering contact to admin";
	public String CLOSING_RESOURCE_ERROR="Error while resource access contact to admin";
	
	
}
