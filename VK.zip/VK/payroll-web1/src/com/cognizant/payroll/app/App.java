package com.cognizant.payroll.app;
import java.sql.*;
import java.util.Scanner;

import com.cognizant.payroll.dao.LoginDao;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.LoginDetails;
public class App {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Username:");
		String username=s.nextLine();
		System.out.println("Enter Password:");
		String password=s.nextLine();
		LoginDetails lg = new LoginDetails(username,password);
		LoginDao lo= new LoginDao();
		String ss="";
		try
		{
		ss=lo.doLogin(new LoginDetails(username,password));
		}
		catch(PayrollException payrollException)
		{
			//payrollException.printStackTrace();
			//throw new Exception(payrollException.getMessage());
			System.out.println(payrollException);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println(ss);
	}

}
