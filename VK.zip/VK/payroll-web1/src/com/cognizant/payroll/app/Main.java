package com.cognizant.payroll.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection connObj = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/payroll", "root", "root");
			System.out.println(connObj);
			if (connObj != null) {
				System.out.println("Got connection");
			} else {

				System.out.println("Error ");
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Class not avaialble to losd");
		}

	}

}
