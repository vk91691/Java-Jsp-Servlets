package com.pack.service;

import com.pack.dao.LoginDaoImpl;
import com.pack.model.Login;

public class LoginServiceImpl implements LoginService {

	public int login(Login l) {
		// TODO Auto-generated method stub
		int i=new LoginDaoImpl().login(l);
		return i;
	}

	public int login(String name, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

}
