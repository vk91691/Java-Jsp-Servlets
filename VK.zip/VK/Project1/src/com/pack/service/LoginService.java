package com.pack.service;

public interface LoginService {

}
