package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.pack.JdbcConnection;
import com.pack.model.Login;

public class LoginDaoImpl implements LoginDao{

	public int login(Login l) {
		// TODO Auto-generated method stub
		Connection con=null;
		ResultSet resultSet=null;
		PreparedStatement preparedStatement=null;
		int i=0;
		try {			
			con=JdbcConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select username,password from login where username=? and password=?");

			ps.setString(1,l.getUsername());
			ps.setString(2,l.getPassword());
			resultSet = preparedStatement.executeQuery();
			i=ps.executeUpdate();	
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		finally {
			try {
				
				if(con != null)
						con.close();
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		return i;
	}

}
