package com.pack.dao;

import com.pack.model.Login;

public interface LoginDao {

	public int login(Login l);
}
