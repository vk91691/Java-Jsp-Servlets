package com.cognizant.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.payroll.exception.IPayrollMessage;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.LoginDetails;
import com.cognizant.payroll.util.Connectionutil;

public class LoginDao 
{
	public static String doLogin(LoginDetails loginDetails) throws PayrollException
	{
		String user="";
		ResultSet rs=null;
		Connection con=null;;
		PreparedStatement ps=null;
		try
		{
			con=Connectionutil.getConnect();
			if(con==null)
			{
				System.out.println("not");
			}
			else
			{
				System.out.println("Got");
			}
			ps =con.prepareStatement("select username,password from login where username=? and password=?");
			ps.setString(1, loginDetails.getUsername());
			ps.setString(2, loginDetails.getPassword());
			rs=ps.executeQuery();
			if(rs.next())
			{
				String uname=rs.getString(1);
				String upass=rs.getString(2);
				user=uname;
			}
			
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			throw new PayrollException(IPayrollMessage.D);
		}
		catch(SQLException sqlException)
		{
			throw new PayrollException(IPayrollMessage.s);
		}
		catch(Exception e)
		{
			throw new PayrollException(e.getMessage());
		}
		finally
		{
			try 
			{
				if(rs!=null)
				{
					rs.close();
				} 
				if(ps!=null)
				{
					ps.close();
				} 
				if(con!=null)
				{
					con.close();
				}
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PayrollException(sqlException.getMessage());
			}
		}
		return user;
	}

}
