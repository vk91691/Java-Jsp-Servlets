package com.cognizant.payroll.app;

import java.sql.*;
import java.util.Scanner;

import com.cognizant.payroll.dao.LoginDao;
import com.cognizant.payroll.exception.IPayrollMessage;
import com.cognizant.payroll.exception.PayrollException;
import com.cognizant.payroll.model.LoginDetails;

public class Main {

	public static void main(String[] args) 
	{
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter Username : ");
			String username=scan.nextLine();
			System.out.println("Enter Password : ");
			String userpassword=scan.nextLine();
			
			LoginDao ld=new LoginDao();
			String u;
			try 
			{
				u = ld.doLogin(new LoginDetails(username,userpassword));
				if(u.equals(""))
				{
					System.out.println("username or password is wrong");
				}
				else
				{
					System.out.println(u+" logged in successfully ");
				}
			} 
			catch (PayrollException e)
			{
				e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println(IPayrollMessage.q);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			
	}

}
