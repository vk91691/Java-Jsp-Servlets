package com.cognizant.payroll.model;

public class LoginDetails 
{
	public String username;
	public String Password;
	public String getUsername() 
	{
		return username;
	}
	public void setUsername(String username) 
	{
		this.username = username;
	}
	public String getPassword() 
	{
		return Password;
	}
	public void setPassword(String password) 
	{
		Password = password;
	}
	public LoginDetails() 
	{
		super();
	}
	public LoginDetails(String username, String password) {
		super();
		this.username = username;
		Password = password;
	}
	
}
