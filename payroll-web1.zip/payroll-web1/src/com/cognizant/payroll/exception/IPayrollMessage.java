package com.cognizant.payroll.exception;

public interface IPayrollMessage 
{
	public String D="Driver Error";
	public String s="SQL Error";
	public String q="contact Admin for solution";
}
