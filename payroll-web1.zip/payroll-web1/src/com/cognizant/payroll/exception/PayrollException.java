package com.cognizant.payroll.exception;

public class PayrollException extends Exception 
{

	public PayrollException() 
	{
		super();
	}
	public PayrollException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public PayrollException(String message) 
	{
		super(message);
	}
	public PayrollException(Throwable cause) 
	{
		super(cause);
	}

}
